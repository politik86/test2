
	    <?php defined('_JEXEC') or die( 'Restricted access' );
	    		/**
				 * @package		AdsManager
				 * @copyright	Copyright (C) 2010-2014 Juloa.com. All rights reserved.
				 * @license		GNU/GPL
				 */
	    		$last_cron_date=20140407;?>