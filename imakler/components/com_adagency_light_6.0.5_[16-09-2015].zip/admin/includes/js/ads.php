<?php
/*------------------------------------------------------------------------
# com_adagency
# ------------------------------------------------------------------------
# author    iJoomla
# copyright Copyright (C) 2013 ijoomla.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.ijoomla.com
# Technical Support:  Forum - http://www.ijoomla.com/forum/index/
-------------------------------------------------------------------------*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 
?>

<?php
	$document = JFactory::getDocument();
?>

<script type="text/javascript">
	function moveupq(x) {
		var current = ADAG('#order' + x);
		current.val(function(index,value) {
			var next = ADAG(this).parents('tr').filter(':first').prev().find('input:last');
			var aux = parseInt(next.val());
			next.val(value);
			return aux;
		});
		Joomla.submitform('saveorder');
	}

	function movedownq(x) {
		var current = ADAG('#order' + x);
		current.val(function(index,value) {
			var next = ADAG(this).parents('tr').filter(':first').next().find('input:last');
			var aux = parseInt(next.val());
			next.val(value);
			return aux;
		});
		Joomla.submitform('saveorder');
	}
</script>
