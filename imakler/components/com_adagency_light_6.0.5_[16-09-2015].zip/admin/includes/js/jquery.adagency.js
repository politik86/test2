ADAG = jQuery.noConflict();
